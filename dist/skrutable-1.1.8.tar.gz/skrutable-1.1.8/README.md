# skrutable

A toolkit and online workbench providing transliteration, scansion, and meter identification for Sanskrit text.

Web-app interface live online at [skrutable.info](https://www.skrutable.info).

See [manual.md](./manual.md) for instructions.

Feedback welcome! Find find [me (Tyler) on Academia](https://uni-leipzig1.academia.edu/TylerNeill) and send me an email.

And please share and share-alike: licensed under a [Creative Commons Attribution-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-sa/4.0/).